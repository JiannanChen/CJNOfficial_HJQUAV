function [sys,x0,str,ts,simStateCompliance] = HJQUAV(t,x,u,flag)

%   Copyright 1990-2010 The MathWorks, Inc.

%
% The following outlines the general structure of an S-function.
%
switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=[];

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=[];

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=[];

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 2;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 0;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = [0.1, 0.1];

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim state
simStateCompliance = 'UnknownSimState';

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,~)
% ϵͳ����
m = 1;

% ���Ʋ���
k1=1;
k2=1;

Td=0.1;
T=1;
p10=3;
p100=0.3;
p20=6;
p200=0.6;

% ���Ʒ���
x1d = sin(0.1*t); 

if t >= Td
    q = 0;
else
    q = (1-t/Td)*exp(1-(Td/(Td-t)));
end

if t >= T
    p1 = p100;
else
    p1 = (p10-t/T)*exp(1-(T/(T-t))) + p100;
end

if t >= T
    p2 = p100;
else
    p2 = (p20-t/T)*exp(1-(T/(T-t))) + p200;
end

hat_z1 = x(1) - x1d; 
x10 = 0.1; % ��ֵ
x1d0 = 0; % ��ֵ
z1 = x(1) - x1d - q*(x10 - x1d0);
xi_1 = z1/p1;
alpha_1 = -k1*log((1+xi_1)/(1-xi_1));

hat_z2 = x(2) - alpha_1;
x20 = 0.1; % ��ֵ
z10=0; % ��ֵ
xi_10 = z10/p1; % ��ֵ
alpha_10 = -k1*log((1+xi_10)/(1-xi_10)); % ��ֵ
z2 = x(2) - alpha_1 - q*(x20 - alpha_10);
xi_2 = z2/p2;
Ux = -k2*log((1+xi_2)/(1-xi_2));

% ϵͳ��̬
sys(1) = x(2);
sys(2) = (1/m)*Ux;

% end mdlDerivatives

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,~)
% ϵͳ����
m = 1;

% ���Ʋ���
k1=1;
k2=1;

Td=0.1;
T=1;
p10=3;
p100=0.3;
p20=6;
p200=0.6;

% ���Ʒ���
x1d = sin(0.1*t); 

if t >= Td
    q = 0;
else
    q = (1-t/Td)*exp(1-(Td/(Td-t)));
end

if t >= T
    p1 = p100;
else
    p1 = (p10-t/T)*exp(1-(T/(T-t))) + p100;
end

if t >= T
    p2 = p100;
else
    p2 = (p20-t/T)*exp(1-(T/(T-t))) + p200;
end

hat_z1 = x(1) - x1d; 
x10 = 0.1; % ��ֵ
x1d0 = 0; % ��ֵ
z1 = x(1) - x1d - q*(x10 - x1d0);
xi_1 = z1/p1;
alpha_1 = -k1*log((1+xi_1)/(1-xi_1));

hat_z2 = x(2) - alpha_1;
x20 = 0.1; % ��ֵ
z10=0; % ��ֵ
xi_10 = z10/p1; % ��ֵ
alpha_10 = -k1*log((1+xi_10)/(1-xi_10)); % ��ֵ
z2 = x(2) - alpha_1 - q*(x20 - alpha_10);
xi_2 = z2/p2;
Ux = -k2*log((1+xi_2)/(1-xi_2));

% ϵͳ���
sys(1) = z1;
sys(2) = z2;


% end mdlOutputs
